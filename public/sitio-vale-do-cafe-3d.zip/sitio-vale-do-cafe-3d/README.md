# Sítio Vale do Café 3D

Projeto Vite modularizado preservando `three@0.128.0` e build single-file via `vite-plugin-singlefile`.

## Como rodar localmente

```bash
npm install
npm run dev
```

Abra o endereço exibido no terminal (padrão `http://localhost:3000`).

## Gerar HTML único autônomo

```bash
npm run build
```

O arquivo único final será gerado em `dist/index.html` (uma cópia já compilada também acompanha este pacote).
